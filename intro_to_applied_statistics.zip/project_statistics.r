# Διαβάζουμε το αρχείο και του λέμε να αγνοήσει εντελώς τα εισαγωγικά
babies <- read.table(file.choose(), header=TRUE, sep=",", quote="")

# Διαγράφω τα κρυφά εισαγωγικά και μετατρέπω τα δεδομένα σε καθαρούς αριθμούς
babies[] <- lapply(babies, function(x) as.numeric(gsub('"', '', x)))

# Βάζω τα σωστά ονόματα
names(babies) <- c("bwt", "gestation", "parity", "age", "height", "weight", "smoke")

# Καθαρισμός δεδομένων
CLEAN <- subset(babies, bwt != 999 & gestation != 999 & parity != 9 & 
                        age != 99 & height != 99 & weight != 999 & smoke != 9)

# έλεγχος (βλέπουμε πόσες γραμμές και στήλες έμειναν μετά τον καθαρισμό)
print(dim(CLEAN))

# Ιστογράμματα 
par(mfrow=c(2,1)) 
hist(CLEAN$bwt[CLEAN$smoke == 0], xlim=c(30,180), col="lightblue", 
     main="Birth Weight of Babies (Non-Smoking Mothers)", xlab="Birth Weight (ounces)")
hist(CLEAN$bwt[CLEAN$smoke == 1], xlim=c(30,180), col="salmon", 
     main="Birth Weight of Babies (Smoking Mothers)", xlab="Birth Weight (ounces)")

# Boxplots 
par(mfrow=c(1,1)) 
boxplot(bwt ~ smoke, data=CLEAN, names=c("Non-Smokers", "Smokers"), 
        col=c("lightblue", "salmon"), ylab="Birth Weight (ounces)", 
        main="Birth Weight Comparison by Smoking Status")


# Διαφορά μέσου βάρους μωρών (Non-smokers - Smokers) 
mean_bwt_nonsmoker <- mean(CLEAN$bwt[CLEAN$smoke == 0])
mean_bwt_smoker <- mean(CLEAN$bwt[CLEAN$smoke == 1])
diff_bwt <- mean_bwt_nonsmoker - mean_bwt_smoker
print(paste("Mean birth weight diff: ", round(diff_bwt, 2)))

# Διαφορά διάμεσου βάρους μωρών (Πρωτότοκα vs Υπόλοιπα) 
median_bwt_first <- median(CLEAN$bwt[CLEAN$parity == 0])
median_bwt_other <- median(CLEAN$bwt[CLEAN$parity != 0])
diff_median_parity <- median_bwt_first - median_bwt_other
print(paste("Median weight diff (Firstborn - Others): ", diff_median_parity))

# Διαφορά μέσου βάρους μητέρας πριν την εγκυμοσύνη 
mean_wt_nonsmoker <- mean(CLEAN$weight[CLEAN$smoke == 0])
mean_wt_smoker <- mean(CLEAN$weight[CLEAN$smoke == 1])
diff_wt <- mean_wt_nonsmoker - mean_wt_smoker
print(paste("Mean mother's weight diff: ", round(diff_wt, 2)))

# Υπολογισμός BWI και δημιουργία του CLEANP
# Μετατροπές σε kg και m σύμφωνα με την εκφώνηση
weight_kg <- CLEAN$weight * 0.45359
height_m <- CLEAN$height * 0.0254

# Υπολογισμός BWI 
BWI <- weight_kg / (height_m^2)

# Αποθήκευση στο νέο dataframe που ονομάζεται CLEANP
CLEANP <- CLEAN
CLEANP$weight_kg <- weight_kg
CLEANP$height_m <- height_m
CLEANP$BWI <- BWI

# Κατανομή του BWI 
# Ένα απλό ιστόγραμμα για να δούμε το σχήμα της κατανομής 
par(mfrow=c(1,1))
hist(CLEANP$BWI, col="lightgreen", main="Distribution of Mothers' BWI", xlab="BWI")

# Διαχωρισμός σε τεταρτημόρια  
# Βρίσκουμε τα όρια των τεταρτημορίων και κόβουμε το BWI σε 4 γκρουπ (Q1, Q2, Q3, Q4)
bwi_quartiles <- quantile(CLEANP$BWI, probs=c(0, 0.25, 0.5, 0.75, 1))
CLEANP$BWI_group <- cut(CLEANP$BWI, breaks=bwi_quartiles, include.lowest=TRUE, labels=c("Q1", "Q2", "Q3", "Q4"))

# Ελέγχω πόσες μητέρες μπήκαν σε κάθε γκρουπ για επιβεβαίωση
table(CLEANP$BWI_group)

# Mean, SD, Median, IQR ανά τεταρτημόριο και κάπνισμα 
print("MEAN")
print(tapply(CLEANP$bwt, list(BWI_Group=CLEANP$BWI_group, Smoke=CLEANP$smoke), mean))

print("STANDARD DEVIATION")
print(tapply(CLEANP$bwt, list(BWI_Group=CLEANP$BWI_group, Smoke=CLEANP$smoke), sd))

print("MEDIAN")
print(tapply(CLEANP$bwt, list(BWI_Group=CLEANP$BWI_group, Smoke=CLEANP$smoke), median))

print("IQR")
print(tapply(CLEANP$bwt, list(BWI_Group=CLEANP$BWI_group, Smoke=CLEANP$smoke), IQR))


# Conditioned Histograms
# Φτιάχνω ένα πλέγμα 4x2 για να χωρέσουν και τα 8 ιστογράμματα
par(mfrow=c(4, 2), mar=c(2, 2, 2, 1))
for(g in c("Q1", "Q2", "Q3", "Q4")) {
  hist(CLEANP$bwt[CLEANP$BWI_group == g & CLEANP$smoke == 0], 
       main=paste(g, "- Non-Smoker"), col="lightblue", xlab="")
  hist(CLEANP$bwt[CLEANP$BWI_group == g & CLEANP$smoke == 1], 
       main=paste(g, "- Smoker"), col="salmon", xlab="")
}


# Scatterplot του bwt με το BWI (με coplot) 
par(mfrow=c(1,1)) # Επαναφορά του παραθύρου
coplot(bwt ~ BWI | BWI_group * as.factor(smoke), data=CLEANP,
       xlab=c("BWI", "Smoking Status (0=Non, 1=Smoker)"), 
       ylab="Birth Weight")


# Πίνακας Smoke by Parity και γράφημα 
smoke_parity_tbl <- table(Smoke=CLEANP$smoke, Parity=CLEANP$parity)
print("Πίνακας Smoke by Parity")
print(smoke_parity_tbl)

# Υπολογισμός ποσοστών ανά στήλη 
prop_tbl <- prop.table(smoke_parity_tbl, margin=2)
print("Ποσοστά % ανά Parity")
print(prop_tbl * 100)

barplot(smoke_parity_tbl, beside=TRUE, col=c("lightblue", "salmon"),
        main="Smoking Status by Parity", xlab="Parity (0 = Firstborn)", 
        ylab="Count of Mothers", legend.text=c("Non-Smoker", "Smoker"))